import java.util.*;
public class PalletObject {
  double totalPalletVolume;
  double totalPalletHeight;
  double totalPalletWeight;
  int palletMaterial;
  //int palletOrderID;

  PalletObject(double newHeight, double newVolume, double newWeight, int ID/*(int newPalletOrderID*/) {
    totalPalletHeight = newHeight;
    totalPalletVolume = newVolume;
    totalPalletWeight = newWeight;
    //palletOrderID = newPalletOrderID;
  }

  PalletObject() {
    
  }
}

