import java.util.*;
class OrderObject {
  ArrayList<PalletObject> orderPalletArrayList = new ArrayList<PalletObject>();
}