import java.util.*;
public class Truck {
  
  
  
  
  
  
  
  
  
  
  //Method to create new Truck and return
  public static TruckCompartments[] createTruckCompartments() {
    TruckCompartments[] truckCompartmentsArray = new TruckCompartments[12];
    
    TruckCompartments CompartmentOne = new TruckCompartments();
    truckCompartmentsArray[0] = CompartmentOne;
    
    TruckCompartments CompartmentTwo = new TruckCompartments();
    truckCompartmentsArray[1] = CompartmentTwo;
    
    TruckCompartments CompartmentThree = new TruckCompartments();
    truckCompartmentsArray[2] = CompartmentThree;
    
    TruckCompartments CompartmentFour = new TruckCompartments();
    truckCompartmentsArray[3] = CompartmentFour;
    
    TruckCompartments CompartmentFive = new TruckCompartments();
    truckCompartmentsArray[4] = CompartmentFive;
    
    TruckCompartments CompartmentSix = new TruckCompartments();
    truckCompartmentsArray[5] = CompartmentSix;
    
    TruckCompartments CompartmentSeven = new TruckCompartments();
    truckCompartmentsArray[6] = CompartmentSeven;
    
    TruckCompartments CompartmentEight = new TruckCompartments();
    truckCompartmentsArray[7] = CompartmentEight;
    
    TruckCompartments CompartmentNine = new TruckCompartments();
    truckCompartmentsArray[8] = CompartmentNine;
    
    TruckCompartments CompartmentTen = new TruckCompartments();
    truckCompartmentsArray[9] = CompartmentTen;
    
    TruckCompartments CompartmentEleven = new TruckCompartments();
    truckCompartmentsArray[10] = CompartmentEleven;
    
    TruckCompartments CompartmentTwelve = new TruckCompartments();
    truckCompartmentsArray[11] = CompartmentTwelve;

    return truckCompartmentsArray;
  }
}